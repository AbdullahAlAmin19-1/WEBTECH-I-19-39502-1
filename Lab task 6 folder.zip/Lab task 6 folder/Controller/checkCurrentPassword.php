<?php 
require 'Model/model.php';
$data=showData($_SESSION['id']);
$password = $data["Password"];
?>