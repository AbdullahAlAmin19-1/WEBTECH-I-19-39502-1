
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<footer class="foot">
	<hr>
  	<p class="textCenter">Copyright &#169 2021</p>
</footer>
</body>
</html>