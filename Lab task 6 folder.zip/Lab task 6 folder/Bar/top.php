<!DOCTYPE html>
<html>
<head>
</head>
<body>
	
<header>
<div class="left">
	<img class="logo" src="Uploads/modern_medical.png" alt="Profile Picture"> 
</div>
<br><br>
<div class="right">
	<a href="welcome.php">Home</a>
	<a href="login.php">Login</a>
	<a href="registration.php">Registration</a>
</div>
</header>
<br><br> 
<hr>

</body>
</html>