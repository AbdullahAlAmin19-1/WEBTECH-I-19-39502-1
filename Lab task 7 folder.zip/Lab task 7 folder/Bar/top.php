<!DOCTYPE html>
<html>
<head>
</head>
<body>
	
<header>
    <nav class="navbar navbar-expand-sm navbar-dark bg-primary">
      <div class="col-xl-9 col-lg-8 col-md-7 col-sm-6 col-12"><img class="logo" src="Uploads/modern_medical.png" alt="Profile Picture">
      </div>

  <div class="col-xl-3 col-lg-4 col-md-5 col-sm-6 col-12">
    <div class="navbar-nav">
      <a class="nav-link" href="welcome.php"><i class="fas fa-home"></i>Home</a>
      <a class="nav-link" href="login.php"><i class="fas fa-sign-in-alt"></i>Login</a>
      <a class="nav-link" href="registration.php"><i class="fas fa-file-alt"></i>Registration</a>
    </div>
  </div>
</nav>
</header>
<br>
</body>
</html>