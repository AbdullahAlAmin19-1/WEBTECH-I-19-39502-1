<?php 

require_once ('Model/model1.php');

function fetchAllData(){
	return showAllData();
}
function fetchData($id){
	return showData($id);
}

function fetchAllData1(){
	return showAllData1();
}
function fetchData1($id){
	return showData1($id);
}

function fetchAllData2(){
	return showAllData2();
}
function fetchData2($id){
	return showData2($id);
}

function fetchAllData3(){
	return showAllData3();
}

function fetchData3($id){
	return showData3($id);
}

?>