<?php 
require 'Model/model1.php';
$data=showData($_SESSION['id']);
$password = $data["Password"];
?>