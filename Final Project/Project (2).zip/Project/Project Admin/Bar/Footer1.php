
<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<div class="container-fluid">
		<footer class="foot navbar-light padding" style="background-color: #0dcaf0;padding: 10px 10px;">
			<h4 class="textCenter">Copyright &#169 2021</h4>
  </footer>
	</div>

</body>
</html>