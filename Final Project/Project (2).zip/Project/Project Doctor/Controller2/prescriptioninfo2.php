<?php 

require_once ('Model2/model2.php');

function fetchAllprescriptions(){
	return showAllPrescriptions();

}
