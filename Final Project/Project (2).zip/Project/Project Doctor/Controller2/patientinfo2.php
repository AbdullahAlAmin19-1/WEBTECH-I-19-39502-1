<?php 

require_once ('Model2/model2.php');

function fetchAllPatients(){
	return showAllPatient();

}
