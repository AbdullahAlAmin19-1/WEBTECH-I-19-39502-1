<?php 
require 'Model2/model2.php';
$data=showData($_SESSION['id']);
$password = $data["Password"];
?>