<?php 
require 'Model3/model3.php';
$data=showData($_SESSION['id']);
$password = $data["Password"];
?>