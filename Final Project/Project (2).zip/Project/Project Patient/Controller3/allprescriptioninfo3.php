<?php 

require_once ('Model3/model3.php');

function fetchAllPrescriptions(){
	return showAllPrescription();

}
