<?php 

require_once ('Model3/model3.php');

function fetchAllPayments(){
	return showAllPayment();

}
