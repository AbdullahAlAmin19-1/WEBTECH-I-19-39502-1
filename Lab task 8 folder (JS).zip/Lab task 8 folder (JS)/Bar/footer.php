
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<footer>
  	<br>
	<div class="foot navbar-dark bg-primary padding">
  		<h6 class="textCenter">Copyright &#169 2021</h6>
	</div>
</footer>
</body>
</html>